package com.example.prodiot

import OptionMenuHandler
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth


class MainMenu : AppCompatActivity() {
    private lateinit var optionMenuHandler: OptionMenuHandler
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mainmenu)

        val userText = findViewById<TextView>(R.id.tv_app_name)

        // Firebase 인증 객체 초기화
        auth = FirebaseAuth.getInstance()
        val user = auth.currentUser
        val author = user?.displayName ?: ""
        userText.text = ("$author 님 환영합니다.")

        // 툴바 설정
        setSupportActionBar(findViewById(R.id.toolbar))
        // 페이지 이동 함수
        val moveToAnotherPage = { destination: Class<*> ->
            startActivity(Intent(this, destination))
            overridePendingTransition(R.anim.left_in, R.anim.left_out)
        }
        // 이벤트 핸들러
        findViewById<Button>(R.id.btn_freeboard).setOnClickListener {
            moveToAnotherPage(FreeBoardList::class.java)
        }
        findViewById<Button>(R.id.btn_codestep).setOnClickListener {
            moveToAnotherPage(CodeStepList::class.java)
        }
        // OptionMenuHandler 초기화
        optionMenuHandler = OptionMenuHandler(this)
    }

    // 옵션 메뉴 생성
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.mainmenu, menu)
        return true
    }

    // 옵션 메뉴 클릭 핸들러
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return optionMenuHandler.handleItemSelected(item) || super.onOptionsItemSelected(item)
    }
}
