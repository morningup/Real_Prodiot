package com.example.prodiot

import OptionMenuHandler
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener


class CodeStepList : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var optionMenuHandler: OptionMenuHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_codesteplist)
        // 툴바 설정
        setSupportActionBar(findViewById(R.id.toolbar))

// 리사이클러뷰 설정
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // 파이어베이스 데이터베이스 초기화
        val firebaseDatabase = FirebaseDatabase.getInstance()
        val databaseReference = firebaseDatabase.reference.child("steps")
        // 파이어베이스 데이터베이스에서 데이터 가져오기
        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val allItems = mutableListOf<Step>()
                for (stepSnapshot in dataSnapshot.children) {
                    val step = stepSnapshot.getValue(Step::class.java)
                    step?.let {
                        val key = stepSnapshot.key // 아이템의 키값 가져오기
                        it.key = key // Post 객체에 키값 저장
                        allItems.add(it)
                    }
                }
                val adapter = codestepadapter(allItems)
                recyclerView.adapter = adapter
            }
            override fun onCancelled(databaseError: DatabaseError) {
                // 오류 처리 (선택사항)
            }
        })




        // 페이지 이동 함수
        val moveToAnotherPage = { destination: Class<*> ->
            startActivity(Intent(this, destination))
            overridePendingTransition(R.anim.left_in, R.anim.left_out)
        }

        // 이벤트 핸들러
        findViewById<Button>(R.id.btn_home).setOnClickListener {
            moveToAnotherPage(MainMenu::class.java)
        }

        findViewById<Button>(R.id.btn_freeboard).setOnClickListener {
            moveToAnotherPage(FreeBoardList::class.java)
        }

        findViewById<Button>(R.id.btn_codestep).setOnClickListener {
            moveToAnotherPage(CodeStepList::class.java)
        }

        findViewById<Button>(R.id.btn_write_test).setOnClickListener {
            moveToAnotherPage(CodeStepWrite::class.java)
        }

        // OptionMenuHandler 초기화
        optionMenuHandler = OptionMenuHandler(this)
    }
    // 옵션 메뉴 생성
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.mainmenu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        return optionMenuHandler.handleItemSelected(item) || super.onOptionsItemSelected(item)
    }
}
