package com.example.prodiot

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class CommentAdapter(private val comments: MutableList<Comment>) : RecyclerView.Adapter<CommentAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val authorTextView: TextView = itemView.findViewById(R.id.commentAuthorTextView)
        val contentTextView: TextView = itemView.findViewById(R.id.commentTextView)
        val deleteButton: AppCompatImageButton = itemView.findViewById(R.id.delete_button)
        val replyButton: AppCompatImageButton = itemView.findViewById(R.id.reply_button)
        val replyRecyclerView: RecyclerView = itemView.findViewById(R.id.replyRecyclerView)
        private val replyAdapter = ReplyAdapter(mutableListOf()) // ReplyAdapter를 ViewHolder 내부에서 선언

        init {
            replyRecyclerView.adapter = replyAdapter
            replyRecyclerView.layoutManager = LinearLayoutManager(itemView.context)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.coment_layout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val comment = comments[position]
        Log.d("TAG", comments.toString())
        holder.authorTextView.text = comment.author
        holder.contentTextView.text = comment.content
        holder.deleteButton.setOnClickListener{
            val selectedComment = comments[position].key
            Log.d("TAG", "$selectedComment")
            if (selectedComment != null) {
                deleteComment(selectedComment)
            }
        }
        // Shared Preferences를 초기화합니다.
        val context = holder.itemView.context
        val sharedPreferences = context.getSharedPreferences("selectedComment", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        // selectedComment 값을 저장합니다.
        editor.putBoolean("isReply", false)
        editor.apply()
        holder.replyButton.setOnClickListener {
            val selectedComment = comments[position].key
            // selectedComment 값을 저장합니다.
            editor.putString("selectedComment", selectedComment)
            editor.putBoolean("isReply", true)
            editor.apply()
        }

        // Comment 객체에서 commentKey를 가져옵니다.
        val commentKey = comment.key

        // 해당 댓글의 답글을 가져옵니다.
        val replies = getRepliesForComment(commentKey.toString())

        // ReplyAdapter를 생성하고 데이터를 설정합니다.
        val replyAdapter = ReplyAdapter(replies)
        holder.replyRecyclerView.adapter = replyAdapter
        holder.replyRecyclerView.layoutManager = LinearLayoutManager(holder.itemView.context)

    }

    private fun getRepliesForComment(commentKey: String): MutableList<Reply> {
        // commentKey에 해당하는 replies를 가져오는 로직을 작성합니다.
        // 이 부분은 파이어베이스나 다른 데이터베이스에서 적절한 쿼리를 실행하여 가져오는 방식으로 구현해야 합니다.
        // 예를 들면 파이어베이스에서 commentKey에 해당하는 replies를 가져오는 방법은 다음과 같습니다.
        val database = FirebaseDatabase.getInstance()
        val repliesRef = database.reference.child("replys").orderByChild("parentkey").equalTo(commentKey)
        val repliesList = mutableListOf<Reply>()
        repliesRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                repliesList.clear()
                for (childSnapshot in snapshot.children) {
                    val reply = childSnapshot.getValue(Reply::class.java)
                    reply?.let {
                        repliesList.add(it)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // 에러 처리 로직을 추가합니다.
            }
        })

        return repliesList
    }

    override fun getItemCount(): Int {
        return comments.size
    }

    fun deleteComment(commentKey: String) {
        val database = FirebaseDatabase.getInstance()
        val commentsRef = database.reference.child("comments")
        commentsRef.child(commentKey).removeValue()
    }
}

class ReplyAdapter(private val replies: MutableList<Reply>) : RecyclerView.Adapter<ReplyAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val replyAuthorTextView: TextView = itemView.findViewById(R.id.replyAuthorTextView)
        val replyTextView: TextView = itemView.findViewById(R.id.replyTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.reply_layout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val reply = replies[position]
        holder.replyAuthorTextView.text = reply.author
        holder.replyTextView.text = reply.content
    }

    override fun getItemCount(): Int {
        return replies.size
    }
}



