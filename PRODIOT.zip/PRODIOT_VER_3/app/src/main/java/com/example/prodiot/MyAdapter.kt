package com.example.prodiot

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class freeboardadapter(private val postList: List<Post>) : RecyclerView.Adapter<freeboardadapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.TitleTextView)
        val authorTextView: TextView = itemView.findViewById(R.id.AuthorTextView)


        init {
            Log.d("TAG", postList.toString())
            itemView.setOnClickListener {
                val position = adapterPosition
                Log.d("TAG", position.toString())
                if (position != RecyclerView.NO_POSITION) {
                    val context = itemView.context
                    Log.d("TAG", position.toString())
                    val intent = Intent(context, FreeBoardView::class.java)
                    // 게시글의 키 값을 인텐트로 전달
                    val selectedKey = postList[position].key

                    Log.d("TAG", selectedKey.toString())
                    intent.putExtra("selected_item", selectedKey)
                    context.startActivity(intent)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_layout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val post = postList[position]
        Log.d("Posts", "post: $post")
        holder.titleTextView.text = post.title
        holder.authorTextView.text = post.author
    }

    override fun getItemCount(): Int {
        return postList.size
    }
}

class codestepadapter(private val stepList: List<Step>) : RecyclerView.Adapter<codestepadapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.TitleTextView)
        val authorTextView: TextView = itemView.findViewById(R.id.AuthorTextView)


        init {
            Log.d("TAG", stepList.toString())
            itemView.setOnClickListener {
                val position = adapterPosition
                Log.d("TAG", position.toString())
                if (position != RecyclerView.NO_POSITION) {
                    val context = itemView.context
                    Log.d("TAG", position.toString())
                    val intent = Intent(context, CodeStepView::class.java)
                    // 게시글의 키 값을 인텐트로 전달
                    val selectedKey = stepList[position].key

                    Log.d("TAG", selectedKey.toString())
                    intent.putExtra("selected_item", selectedKey)
                    context.startActivity(intent)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_layout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val step = stepList[position]
        holder.titleTextView.text = step.title
        holder.authorTextView.text = step.author
    }

    override fun getItemCount(): Int {
        return stepList.size
    }
}



//class codestepadapter(private val stepList: List<Step>) : RecyclerView.Adapter<codestepadapter.ViewHolder>() {
//    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        val titleTextView: TextView = itemView.findViewById(R.id.TitleTextView)
//        val authorTextView: TextView = itemView.findViewById(R.id.AuthorTextView)
//
//        init {
//            itemView.setOnClickListener {
//                val position = adapterPosition
//                if (position != RecyclerView.NO_POSITION) {
//                    val context = itemView.context
//                    val intent = Intent(context, CodeStepView::class.java)
//                    intent.putExtra("selected_item", stepList[position].title)
//                    Log.d("TAG", stepList[position].toString())
//                    context.startActivity(intent)
//                }
//            }
//        }
//    }
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
//        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_layout, parent, false)
//        return ViewHolder(view)
//    }
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        val step = stepList[position]
//        holder.titleTextView.text = step.title
//        holder.authorTextView.text = step.author
//    }
//    override fun getItemCount(): Int {
//        return stepList.size
//    }
//}



