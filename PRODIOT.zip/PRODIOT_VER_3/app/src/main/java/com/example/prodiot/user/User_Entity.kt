package com.example.prodiot

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class User(
    @PrimaryKey val pkId: Int?,
    @ColumnInfo val email: String?,
    @ColumnInfo val pw:String?,
    @ColumnInfo val name:String
)