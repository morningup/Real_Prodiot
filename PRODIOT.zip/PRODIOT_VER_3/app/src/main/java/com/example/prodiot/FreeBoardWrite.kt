package com.example.prodiot

import OptionMenuHandler
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.*
import org.jsoup.Jsoup
import java.util.Date

class FreeBoardWrite : AppCompatActivity() {

    private lateinit var titleEditText: EditText
    private lateinit var contentEditText: EditText
    private lateinit var codeEditText: EditText
    private lateinit var inputEditText: EditText
    private lateinit var createButton: Button
    private lateinit var optionMenuHandler: OptionMenuHandler
    private lateinit var auth: FirebaseAuth
    private lateinit var webViewHelper: PostWebViewHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_freeboardwrite)

        // Firebase 인증 객체 초기화
        auth = FirebaseAuth.getInstance()

        titleEditText = findViewById(R.id.title_edittext)
        contentEditText = findViewById(R.id.content_edittext)
        codeEditText = findViewById(R.id.code_edittext)
        inputEditText = findViewById(R.id.input_edittext)
        createButton = findViewById(R.id.btn_write_test)

        createButton.setOnClickListener {
            val title = titleEditText.text.toString().trim()
            val content = contentEditText.text.toString().trim()
            val code = codeEditText.text.toString().trim()
            val input = inputEditText.text.toString().trim()
            val user = auth.currentUser
            val author = user?.displayName ?: ""
            val timestamp = Date(System.currentTimeMillis())

            if (title.isNotEmpty() && content.isNotEmpty() && author.isNotEmpty()) {
                savePost(title, content, author, code, input, timestamp)
                val intent = Intent(this, FreeBoardList::class.java)
                startActivity(intent)
                finish()
            }
        }

        val webView: WebView = findViewById(R.id.webView)
        val movebutton = findViewById<Button>(R.id.btn_run)
        val sharedPref = getSharedPreferences("post_data", Context.MODE_PRIVATE)

        movebutton.setOnClickListener {
            val progressDialog = CustomProgressDialog(this)
            progressDialog.show()
            val editor = sharedPref.edit()
            editor.putString("CodeString", codeEditText.toString())
            editor.putString("InputString", inputEditText.toString())
            editor.apply()
            webViewHelper = PostWebViewHelper(this)
            webViewHelper.configureWebView(webView)
            webViewHelper.submitCode(webView, progressDialog)
        }
    }

    private fun savePost(title: String, content: String, author: String,
                         code: String, input: String, timestamp: Date) {
        val database = FirebaseDatabase.getInstance()
        val postsRef = database.reference.child("posts")
        val newPostRef = postsRef.push()

        val post = HashMap<String, Any>()
        post["title"] = title
        post["content"] = content
        post["author"] = author
        post["code"] = code
        post["input"] = input
        post["timestamp"] = timestamp

        newPostRef.setValue(post).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                // 게시글 저장 성공
                titleEditText.text.clear()
                contentEditText.text.clear()
                codeEditText.text.clear()
                inputEditText.text.clear()
            } else {
                // 게시글 저장 실패
            }
        }
        // 툴바 설정
        setSupportActionBar(findViewById(R.id.toolbar))

        // 페이지 이동 함수
        val moveToAnotherPage = { destination: Class<*> ->
            startActivity(Intent(this, destination))
            overridePendingTransition(R.anim.left_in, R.anim.left_out)
        }

        // 이벤트 핸들러
        findViewById<Button>(R.id.btn_home).setOnClickListener {
            moveToAnotherPage(MainMenu::class.java)
        }

        findViewById<Button>(R.id.btn_freeboard).setOnClickListener {
            moveToAnotherPage(FreeBoardList::class.java)
        }

        findViewById<Button>(R.id.btn_codestep).setOnClickListener {
            moveToAnotherPage(CodeStepList::class.java)
        }
    }
    // 옵션 메뉴 생성
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.mainmenu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return optionMenuHandler.handleItemSelected(item) || super.onOptionsItemSelected(item)
    }
}
