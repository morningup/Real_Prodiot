package com.example.prodiot

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth


class AppUserInfo : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_userinfo)

        val moveButton = findViewById<Button>(R.id.btn_back)
        moveButton.setOnClickListener {
            onBackPressed()
        }

        // Firebase 인증 객체 초기화
        auth = FirebaseAuth.getInstance()

        val userText = findViewById<TextView>(R.id.usertext)
        val user = auth.currentUser
        val author = user?.displayName ?: ""
        userText.text = author

        val nameText = findViewById<TextView>(R.id.et_name)
        val name = user?.displayName ?: ""
        nameText.text = name

        // 사용자 아이디 표시
        val emailText = findViewById<TextView>(R.id.et_id)
        val email = user?.email ?: ""
        emailText.text = email
    }
}
