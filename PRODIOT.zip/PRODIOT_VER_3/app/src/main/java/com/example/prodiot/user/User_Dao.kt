package com.example.prodiot.user

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.prodiot.User

@Dao
interface UserDao {
    @Insert
    fun insertUser(userInfo: User)

    @Query("select email from User")
    fun getEmail(): List<String>

    @Query("select pw from User where email = :email")
    fun getPwByEmail(email: String):String

    @Query("select name from User where email = :email")
    fun getNameByEmail(email: String): String

    @Query("select * from User where email = :email")
    fun getUserByEmail(email: String): User?
}
