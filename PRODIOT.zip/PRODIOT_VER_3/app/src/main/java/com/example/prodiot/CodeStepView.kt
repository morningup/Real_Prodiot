package com.example.prodiot

import OptionMenuHandler
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.*
import org.jsoup.Jsoup

class CodeStepView : AppCompatActivity() {

    private lateinit var optionMenuHandler: OptionMenuHandler
    private lateinit var webViewHelper: StepWebViewHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_codestepview)

        val TitleView = findViewById<TextView>(R.id.title_edittext)
        val CodeView = findViewById<TextView>(R.id.code_edittext)
        val AuthorView = findViewById<TextView>(R.id.author_edittext)
        val InputView = findViewById<TextView>(R.id.input_edittext)
        val CreatedAtView = findViewById<TextView>(R.id.created_at_edittext)

        val key = intent.getStringExtra("selected_item")

        val webView: WebView = findViewById(R.id.webView)
        val movebutton = findViewById<Button>(R.id.btn_run)
        val sharedPref = getSharedPreferences("step_data", Context.MODE_PRIVATE)
        movebutton.setOnClickListener {
            val progressDialog = CustomProgressDialog(this)
            progressDialog.show()
            val editor = sharedPref.edit()
            editor.putString("CodeString", CodeView.toString())
            editor.putString("InputString", InputView.toString())
            editor.apply()

            webViewHelper = StepWebViewHelper(this)
            webViewHelper.configureWebView(webView)
            webViewHelper.submitCode(webView, progressDialog)
        }

        // 툴바 설정
        setSupportActionBar(findViewById(R.id.toolbar))

        // 페이지 이동 함수
        val moveToAnotherPage = { destination: Class<*> ->
            startActivity(Intent(this, destination))
            overridePendingTransition(R.anim.left_in, R.anim.left_out)
        }

        // 이벤트 핸들러
        findViewById<Button>(R.id.btn_home).setOnClickListener {
            moveToAnotherPage(MainMenu::class.java)
        }

        findViewById<Button>(R.id.btn_freeboard).setOnClickListener {
            moveToAnotherPage(FreeBoardList::class.java)
        }

        findViewById<Button>(R.id.btn_codestep).setOnClickListener {
            moveToAnotherPage(CodeStepList::class.java)
        }

        // OptionMenuHandler 초기화
        optionMenuHandler = OptionMenuHandler(this)

        val firebaseDatabase = FirebaseDatabase.getInstance()
        val databaseReference = firebaseDatabase.reference.child("steps")
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                // 데이터베이스에서 해당 게시물에 대한 데이터 가져오기
                val stepSnapshot = dataSnapshot.child(key.toString())
                Log.d("FreeboardView", "step: $stepSnapshot")
                val step = stepSnapshot.getValue(Step::class.java)
                // 가져온 데이터를 뷰에 설정
                step?.let {
                    TitleView.text = step.title
                    CodeView.text = step.code
                    AuthorView.text = step.author
                    InputView.text = step.input
                    CreatedAtView.text = step.timestamp.toString()
                    findViewById<Toolbar>(R.id.toolbar).title = step.title
                }
            }
            override fun onCancelled(error: DatabaseError) {
                // 오류 처리
                Log.e("CodeStepView", "Failed to read step data.", error.toException())
            }
        })
    }

    // 옵션 메뉴 생성
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.mainmenu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return optionMenuHandler.handleItemSelected(item) || super.onOptionsItemSelected(item)
    }
}
