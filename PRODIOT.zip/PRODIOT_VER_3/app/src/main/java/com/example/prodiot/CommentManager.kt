package com.example.prodiot

import android.util.Log
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

// 게시물에 대한 댓글을 관리하는 클래스
class CommentManager(private val postId: String) {
    private val commentsRef = FirebaseDatabase.getInstance().getReference("comments")

    // 게시물에 댓글을 추가하는 함수
    fun addComment(comment: Comment) {
        commentsRef.push().setValue(comment)
    }

    // 게시물에 달린 모든 댓글을 가져오는 함수
    fun getAllComments(callback: (List<Comment>) -> Unit) {
        commentsRef.orderByChild("postId").equalTo(postId).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val comments = mutableListOf<Comment>()
                    for (childSnapshot in snapshot.children) {
                        val comment = childSnapshot.getValue(Comment::class.java)
                        comment?.let {
                            val key = childSnapshot.key
                            Log.d("FreeboardView", "post: $key")
                            it.key = key
                            Log.d("FreeboardView", "post: $it")
                            comments.add(it)
                            Log.d("FreeboardView", "post: $comments")
                        }
                    }
                    callback(comments)
                }

                override fun onCancelled(error: DatabaseError) {
                    // 에러 처리
                }
            })
    }

    // 댓글에 대한 답글을 추가하는 함수
    fun addReply(parentId: String, reply: Comment) {
        commentsRef.push().setValue(reply.copy(parent = parentId, depth = 1))
    }

    // 댓글의 답글에 대한 답글을 추가하는 함수
    fun addNestedReply(parentId: String, reply: Comment) {
        commentsRef.push().setValue(reply.copy(parent = parentId, depth = 2))
    }

    // 특정 댓글에 대한 모든 답글을 가져오는 함수
    fun getRepliesForComment(commentId: String, callback: (List<Comment>) -> Unit) {
        commentsRef.orderByChild("parent").equalTo(commentId)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val replies = mutableListOf<Comment>()
                    for (childSnapshot in snapshot.children) {
                        val reply = childSnapshot.getValue(Comment::class.java)
                        reply?.let {
                            replies.add(it)
                        }
                    }
                    callback(replies)
                }

                override fun onCancelled(error: DatabaseError) {
                    // 에러 처리
                }
            })
    }
}
